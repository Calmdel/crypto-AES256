// 导入询问模块
const choice = require("./lib/core/mychoices");
// 导入执行模块
const { encrypto, decrypto } = require("./lib/core/myaction");

async function main() {
  //询问对文件进行加密还是解密
  const mychoice = await choice();
  if (mychoice.crypto == "加密") {
    encrypto();//加密
  } else {
    decrypto();//解密
  }
}
main();
